const { Plugin, MarkdownRenderChild, Notice } = require('obsidian');

const BLOCK_LANG = 'simplesheet';
const DEFAULT_ROWS = 3;
const DEFAULT_COLS = 3;

function parseGrid(source) {
  const lines = source.split('\n').filter((l) => l.trim().length > 0 || l === '');
  const rows = lines
    .filter((l) => l.length > 0)
    .map((line) => line.split('|').map((cell) => cell.trim()));
  if (rows.length === 0) {
    return emptyGrid(DEFAULT_ROWS, DEFAULT_COLS);
  }
  const maxCols = Math.max(...rows.map((r) => r.length));
  return rows.map((r) => {
    const row = r.slice();
    while (row.length < maxCols) row.push('');
    return row;
  });
}

function serializeGrid(grid) {
  return grid.map((row) => row.join(' | ')).join('\n');
}

function emptyGrid(rows, cols) {
  return Array.from({ length: rows }, () => Array.from({ length: cols }, () => ''));
}

class SimpleSheetView extends MarkdownRenderChild {
  constructor(containerEl, source, ctx, plugin) {
    super(containerEl);
    this.source = source;
    this.ctx = ctx;
    this.plugin = plugin;
    this.grid = parseGrid(source);
    this.saveTimeout = null;
  }

  onload() {
    this.render();
  }

  scheduleSave() {
    if (this.saveTimeout) window.clearTimeout(this.saveTimeout);
    this.saveTimeout = window.setTimeout(() => this.save(), 400);
  }

  async save() {
    const info = this.ctx.getSectionInfo(this.containerEl);
    if (!info) return;
    const file = this.plugin.app.vault.getAbstractFileByPath(this.ctx.sourcePath);
    if (!file) return;
    const content = await this.plugin.app.vault.read(file);
    const lines = content.split('\n');
    const before = lines.slice(0, info.lineStart + 1);
    const after = lines.slice(info.lineEnd);
    const newBody = serializeGrid(this.grid).split('\n');
    const newContent = [...before, ...newBody, ...after].join('\n');
    await this.plugin.app.vault.modify(file, newContent);
  }

  addRow() {
    const cols = this.grid[0] ? this.grid[0].length : DEFAULT_COLS;
    this.grid.push(Array.from({ length: cols }, () => ''));
    this.render();
    this.scheduleSave();
  }

  addCol() {
    this.grid = this.grid.map((row) => [...row, '']);
    this.render();
    this.scheduleSave();
  }

  removeRow() {
    if (this.grid.length <= 1) {
      new Notice('Deve restare almeno una riga');
      return;
    }
    this.grid.pop();
    this.render();
    this.scheduleSave();
  }

  removeCol() {
    if (!this.grid[0] || this.grid[0].length <= 1) {
      new Notice('Deve restare almeno una colonna');
      return;
    }
    this.grid = this.grid.map((row) => row.slice(0, -1));
    this.render();
    this.scheduleSave();
  }

  render() {
    const el = this.containerEl;
    el.empty();
    el.addClass('simple-sheet-wrapper');

    const toolbar = el.createDiv({ cls: 'simple-sheet-toolbar' });
    const mkBtn = (label, onClick) => {
      const b = toolbar.createEl('button', { text: label, cls: 'simple-sheet-btn' });
      b.addEventListener('click', onClick);
      return b;
    };
    mkBtn('+ Riga', () => this.addRow());
    mkBtn('+ Colonna', () => this.addCol());
    mkBtn('- Riga', () => this.removeRow());
    mkBtn('- Colonna', () => this.removeCol());

    const tableWrap = el.createDiv({ cls: 'simple-sheet-scroll' });
    const table = tableWrap.createEl('table', { cls: 'simple-sheet-table' });

    this.grid.forEach((row, rowIdx) => {
      const tr = table.createEl('tr');
      if (rowIdx === 0) tr.addClass('simple-sheet-header-row');
      row.forEach((cellValue, colIdx) => {
        const cellTag = rowIdx === 0 ? 'th' : 'td';
        const td = tr.createEl(cellTag, { cls: 'simple-sheet-cell' });
        td.setAttribute('contenteditable', 'true');
        td.setAttribute('spellcheck', 'false');
        td.textContent = cellValue;
        td.addEventListener('input', () => {
          this.grid[rowIdx][colIdx] = td.textContent || '';
          this.scheduleSave();
        });
        td.addEventListener('keydown', (evt) => {
          if (evt.key === 'Enter') {
            evt.preventDefault();
            td.blur();
          }
        });
      });
    });
  }
}

module.exports = class SimpleSheetPlugin extends Plugin {
  async onload() {
    this.registerMarkdownCodeBlockProcessor(BLOCK_LANG, (source, el, ctx) => {
      const view = new SimpleSheetView(el, source, ctx, this);
      ctx.addChild(view);
    });

    this.addCommand({
      id: 'insert-simple-sheet',
      name: 'Inserisci nuovo Simple Sheet',
      editorCallback: (editor) => {
        const grid = emptyGrid(DEFAULT_ROWS, DEFAULT_COLS);
        const body = serializeGrid(grid);
        editor.replaceSelection('```' + BLOCK_LANG + '\n' + body + '\n```\n');
      },
    });
  }
};
